const navBtn = document.querySelector(".menubar-btn")
const menu2 = document.querySelector(".menu2")
let navOpen = false;
navBtn.addEventListener("click", function () {
    if (navOpen) {
        navBtn.classList.remove("menubar-btn-open")
        menu2.classList.remove("open")
        navOpen = false
    } else {
        navBtn.classList.add("menubar-btn-open")
        menu2.classList.add("open")
        navOpen = true
    }
})
