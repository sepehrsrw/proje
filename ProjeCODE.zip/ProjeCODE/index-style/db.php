<?php   
// اگر اطلاعات به این صفحه ارسال شده است
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // اطلاعات ورودی را دریافت می‌کنیم
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    // اتصال به پایگاه داده MySQL
    $servername = "localhost";
    $username = "root";
    $password_db = "";
    $dbname = "user";

    // ایجاد اتصال
    $conn = new mysqli($servername, $username, $password_db, $dbname);

    // بررسی اتصال
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // استفاده از Prepared Statements برای جلوگیری از SQL Injection
    $sql = "INSERT INTO users (name, email, password) VALUES ('$name' , '$email' , '$password' )";
    $stmt = mysqli_query($conn, $sql);


    // اجرای استعلام
    if ($stmt) {
        echo "$name , Welcome to our website!";  
        setcookie("name", $name);
    } else {
        echo "خطا در ثبت‌نام: " . $conn->error;
    }

    // بستن اتصال
mysqli_close($conn);
}


?>