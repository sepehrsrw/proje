<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Camping web</title>
        <link rel="icon" href="../svgs/logo.svg">
        <link rel="stylesheet" href="reset.css">
        <link rel="stylesheet" href="font.css">
        <link rel="stylesheet" href="grid.css">
        <link rel="stylesheet" href="style.css">
        <link rel="stylesheet" href="responsive.css">
        <link rel="stylesheet" href="sing.html">
    </head>
    <body>
        <header class="header">
            <div class="container">
                <nav class="nav">
                    <div class="nav-wrapper">
                        <a href="#" class="header-logo">
                            <img src="../svgs/logo.svg" alt="Camping Web" class="logo">
                        </a>
                        <ul class="menu">
                            <li class="menu-item">
                                <a href="#" class="menu-link active-page">Home</a>
                            </li>
                            <li class="menu-item">
                                <a href="#" class="menu-link">Distination</a>
                            </li>
                            <li class="menu-item">
                                <a href="#" class="menu-link">Near me</a>
                            </li>
                            <li class="menu-item">
                                <a href="#" class="menu-link">Events</a>
                            </li>
                            <li class="menu-item">
                                <a href="#" class="menu-link">Blog</a>
                            </li>
                            <li class="menu-item">
                                <a href="#" class="menu-link">Gallery</a>
                            </li>
                            <li class="menu-item">
                                <a href="#" class="menu-link">About</a>
                            </li>
                            <li class="menu-item">
                                <a href="#" class="menu-link">Contact us</a>
                            </li>
                        </ul>
                    </div>
                    <div class="menu2">
                        <ul class="mobile-menu">
                            <h2 class="mobile-menu-title">Camping Website</h2>
                            <li class="mobile-menu-item">
                                <a href="#" class="mobile-menu-link active-2">Home</a>
                            </li>
                            <li class="mobile-menu-item">
                                <a href="#" class="mobile-menu-link">Distination</a>
                            </li>
                            <li class="mobile-menu-item">
                                <a href="#" class="mobile-menu-link">Near me</a>
                            </li>
                            <li class="mobile-menu-item">
                                <a href="#" class="mobile-menu-link">Events</a>
                            </li>
                            <li class="mobile-menu-item">
                                <a href="#" class="mobile-menu-link">Blog</a>
                            </li>
                            <li class="mobile-menu-item">
                                <a href="#" class="mobile-menu-link">Gallery</a>
                            </li>
                            <li class="mobile-menu-item">
                                <a href="#" class="mobile-menu-link">About</a>
                            </li>
                            <li class="mobile-menu-item">
                                <a href="#" class="mobile-menu-link">Contact us</a>
                            </li>
                        </ul>
                        <div class="mobile-menu-sign">
                            <a href="#" class="mobile-menu-sign-link">Sign up</a>
                            <a href="#" class="mobile-menu-sign-link border-mobile">Sign in</a>
                        </div>
                    </div>
                    <div class="sign">
                        <a href="#" class="sign-link">Sign up</a>
                        <a href="./sing.html" class="sign-link border">Sign in</a> 
                    </div>
                    <div class="username-wrapper">
                            <p class="sign-username" style="color:#fff;font-size:2.5rem;font-family: Archivo-Black;cursor:pointer;">
                                <?php 
                                    $val = $_COOKIE["name"];
                                    echo $val;
                                ?>
                            </p>
                    </div>
                    
                    <div class="menubar-btn">
                        <span class="menubar-btn-line"></span>
                    </div>
                </nav>
                <div class="header-content-wrapper">
                    <h1 class="header-title">Find Yourself Outside.</h1>
                    <p class="header-caption">Book unique camping experiences on over 300,000 campsites, cabins, RV parks, public parks and more.</p>
                    <a href="#" class="btn header-link">Discover</a>
                </div>
            </div>
        </header>
        <main class="main">
            <div class="container">
                <section class="services">
                    <div class="services-item">
                        <img src="../svgs/fire.svg" alt="Fire" class="service-banner">
                        <h2 class="service-title">Camping & Day Use</h2>
                        <p class="service-caption">Return to your favorite spot or discover a new one that’s right for you.</p>
                    </div>
                    <div class="services-item">
                        <img src="../svgs/tickets.svg" alt="Ticket" class="service-banner">
                        <h2 class="service-title">Tours & Tickets</h2>
                        <p class="service-caption">Reserve tours and tickets to participate in events.</p>
                    </div>
                    <div class="services-item">
                        <img src="../svgs/paper.svg" alt="paper" class="service-banner">
                        <h2 class="service-title">Permits</h2>
                        <p class="service-caption">Obtain permits for access to high-demand locations.</p>
                    </div>
                    <div class="services-item">
                        <img src="../svgs/fish.svg" alt="Fish" class="service-banner">
                        <h2 class="service-title">Recreation Activities</h2>
                        <p class="service-caption">Find the best spots for hunting, fishing & recreational shooting.</p>
                    </div>
                </section>
                <section class="destinations">
                    <img src="../svgs/destination.svg" alt="Destination" class="destinations-img">
                    <h2 class="destination-title">Explore Destinations & Activities</h2>
                    <div class="places">
                        <div class="palce">
                            <div class="place-banner">
                                <img src="../images/image1.jpg" alt="" class="place-img">
                                <div class="place-like">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="place-like-icon" width="24.037" height="24.037" viewBox="0 0 24.037 24.037" fill="#fff" stroke="#e76f51" stroke-width="1.5">
                                        <path id="Path_955" data-name="Path 955" d="M15.822,8.979v.029H4V-2.1A5.915,5.915,0,0,1,9.912-7.841a5.913,5.913,0,0,1,5.849,5.049,5.912,5.912,0,0,1,.061,11.772Z" transform="translate(2.716 20.496) rotate(-45)"/>
                                    </svg>                                      
                                </div>
                                <div class="place-price">
                                    <p class="place-price-txt">$36/night</p>
                                </div>
                            </div>
                            <h3 class="place-title">Trickle Creek Ranch</h3>
                            <p class="place-caption">Book unique camping experiences on over 300,000 campsites.</p>
                            <a href="#" class="btn place-link">Read More</a>
                        </div>
                        <div class="palce">
                            <div class="place-banner">
                                <img src="../images/image2.jpg" alt="" class="place-img">
                                <div class="place-like">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="place-like-icon active-3" width="24.037" height="24.037" viewBox="0 0 24.037 24.037" fill="#fff" stroke="#e76f51" stroke-width="1.5">
                                        <path id="Path_955" data-name="Path 955" d="M15.822,8.979v.029H4V-2.1A5.915,5.915,0,0,1,9.912-7.841a5.913,5.913,0,0,1,5.849,5.049,5.912,5.912,0,0,1,.061,11.772Z" transform="translate(2.716 20.496) rotate(-45)"/>
                                    </svg>   
                                </div>
                                <div class="place-price">
                                    <p class="place-price-txt">$36/night</p>
                                </div>
                            </div>
                            <h3 class="place-title">Dragonfly Tiny Cabin</h3>
                            <p class="place-caption">Book unique camping experiences on over 300,000 campsites.</p>
                            <a href="#" class="btn place-link">Read More</a>
                        </div>
                        <div class="palce">
                            <div class="place-banner">
                                <img src="../images/image3.jpg" alt="" class="place-img">
                                <div class="place-like">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="place-like-icon" width="24.037" height="24.037" viewBox="0 0 24.037 24.037" fill="#fff" stroke="#e76f51" stroke-width="1.5">
                                        <path id="Path_955" data-name="Path 955" d="M15.822,8.979v.029H4V-2.1A5.915,5.915,0,0,1,9.912-7.841a5.913,5.913,0,0,1,5.849,5.049,5.912,5.912,0,0,1,.061,11.772Z" transform="translate(2.716 20.496) rotate(-45)"/>
                                    </svg> 
                                </div>
                                <div class="place-price">
                                    <p class="place-price-txt">$36/night</p>
                                </div>
                            </div>
                            <h3 class="place-title">Tiny Cabin in the mountains</h3>
                            <p class="place-caption">Book unique camping experiences on over 300,000 campsites.</p>
                            <a href="#" class="btn place-link">Read More</a>
                        </div>
                        <div class="palce">
                            <div class="place-banner">
                                <img src="../images/image4.jpg" alt="" class="place-img">
                                <div class="place-like">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="place-like-icon" width="24.037" height="24.037" viewBox="0 0 24.037 24.037" fill="#fff" stroke="#e76f51" stroke-width="1.5">
                                        <path id="Path_955" data-name="Path 955" d="M15.822,8.979v.029H4V-2.1A5.915,5.915,0,0,1,9.912-7.841a5.913,5.913,0,0,1,5.849,5.049,5.912,5.912,0,0,1,.061,11.772Z" transform="translate(2.716 20.496) rotate(-45)"/>
                                    </svg>  
                                </div>
                                <div class="place-price">
                                    <p class="place-price-txt">$36/night</p>
                                </div>
                            </div>
                            <h3 class="place-title">The Stuga</h3>
                            <p class="place-caption">Book unique camping experiences on over 300,000 campsites.</p>
                            <a href="#" class="btn place-link">Read More</a>
                        </div>
                        <div class="palce">
                            <div class="place-banner">
                                <img src="../images/image5.jpg" alt="" class="place-img">
                                <div class="place-like">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="place-like-icon" width="24.037" height="24.037" viewBox="0 0 24.037 24.037" fill="#fff" stroke="#e76f51" stroke-width="1.5">
                                        <path id="Path_955" data-name="Path 955" d="M15.822,8.979v.029H4V-2.1A5.915,5.915,0,0,1,9.912-7.841a5.913,5.913,0,0,1,5.849,5.049,5.912,5.912,0,0,1,.061,11.772Z" transform="translate(2.716 20.496) rotate(-45)"/>
                                    </svg> 
                                </div>
                                <div class="place-price">
                                    <p class="place-price-txt">$36/night</p>
                                </div>
                            </div>
                            <h3 class="place-title">Luxury Tiny Beach Cabin</h3>
                            <p class="place-caption">Book unique camping experiences on over 300,000 campsites.</p>
                            <a href="#" class="btn place-link">Read More</a>
                        </div>
                        <div class="palce">
                            <div class="place-banner">
                                <img src="../images/image6.jpg" alt="" class="place-img">
                                <div class="place-like">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="place-like-icon" width="24.037" height="24.037" viewBox="0 0 24.037 24.037" fill="#fff" stroke="#e76f51" stroke-width="1.5">
                                        <path id="Path_955" data-name="Path 955" d="M15.822,8.979v.029H4V-2.1A5.915,5.915,0,0,1,9.912-7.841a5.913,5.913,0,0,1,5.849,5.049,5.912,5.912,0,0,1,.061,11.772Z" transform="translate(2.716 20.496) rotate(-45)"/>
                                    </svg> 
                                </div>
                                <div class="place-price">
                                    <p class="place-price-txt">$36/night</p>
                                </div>
                            </div>
                            <h3 class="place-title">The Summit Cabin</h3>
                            <p class="place-caption">Book unique camping experiences on over 300,000 campsites.</p>
                            <a href="#" class="btn place-link">Read More</a>
                        </div>
                        <div class="palce">
                            <div class="place-banner">
                                <img src="../images/image7.jpg" alt="" class="place-img">
                                <div class="place-like">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="place-like-icon" width="24.037" height="24.037" viewBox="0 0 24.037 24.037" fill="#fff" stroke="#e76f51" stroke-width="1.5">
                                        <path id="Path_955" data-name="Path 955" d="M15.822,8.979v.029H4V-2.1A5.915,5.915,0,0,1,9.912-7.841a5.913,5.913,0,0,1,5.849,5.049,5.912,5.912,0,0,1,.061,11.772Z" transform="translate(2.716 20.496) rotate(-45)"/>
                                    </svg> 
                                </div>
                                <div class="place-price">
                                    <p class="place-price-txt">$36/night</p>
                                </div>
                            </div>
                            <h3 class="place-title">Kindred Spirits Cabin</h3>
                            <p class="place-caption">Book unique camping experiences on over 300,000 campsites.</p>
                            <a href="#" class="btn place-link">Read More</a>
                        </div>
                        <div class="palce">
                            <div class="place-banner">
                                <img src="../images/image8.jpg" alt="" class="place-img">
                                <div class="place-like">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="place-like-icon" width="24.037" height="24.037" viewBox="0 0 24.037 24.037" fill="#fff" stroke="#e76f51" stroke-width="1.5">
                                        <path id="Path_955" data-name="Path 955" d="M15.822,8.979v.029H4V-2.1A5.915,5.915,0,0,1,9.912-7.841a5.913,5.913,0,0,1,5.849,5.049,5.912,5.912,0,0,1,.061,11.772Z" transform="translate(2.716 20.496) rotate(-45)"/>
                                    </svg> 
                                </div>
                                <div class="place-price">
                                    <p class="place-price-txt">$36/night</p>
                                </div>
                            </div>
                            <h3 class="place-title">The Hermitage Cabin</h3>
                            <p class="place-caption">Book unique camping experiences on over 300,000 campsites.</p>
                            <a href="#" class="btn place-link">Read More</a>
                        </div>
                        <div class="palce">
                            <div class="place-banner">
                                <img src="../images/image9.jpg" alt="" class="place-img">
                                <div class="place-like">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="place-like-icon" width="24.037" height="24.037" viewBox="0 0 24.037 24.037" fill="#fff" stroke="#e76f51" stroke-width="1.5">
                                        <path id="Path_955" data-name="Path 955" d="M15.822,8.979v.029H4V-2.1A5.915,5.915,0,0,1,9.912-7.841a5.913,5.913,0,0,1,5.849,5.049,5.912,5.912,0,0,1,.061,11.772Z" transform="translate(2.716 20.496) rotate(-45)"/>
                                    </svg> 
                                </div>
                                <div class="place-price">
                                    <p class="place-price-txt">$36/night</p>
                                </div>
                            </div>
                            <h3 class="place-title">Red Lifeguard Stand</h3>
                            <p class="place-caption">Book unique camping experiences on over 300,000 campsites.</p>
                            <a href="#" class="btn place-link">Read More</a>
                        </div>
                        <div class="palce">
                            <div class="place-banner">
                                <img src="../images/image10.jpg" alt="" class="place-img">
                                <div class="place-like">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="place-like-icon" width="24.037" height="24.037" viewBox="0 0 24.037 24.037" fill="#fff" stroke="#e76f51" stroke-width="1.5">
                                        <path id="Path_955" data-name="Path 955" d="M15.822,8.979v.029H4V-2.1A5.915,5.915,0,0,1,9.912-7.841a5.913,5.913,0,0,1,5.849,5.049,5.912,5.912,0,0,1,.061,11.772Z" transform="translate(2.716 20.496) rotate(-45)"/>
                                    </svg> 
                                </div>
                                <div class="place-price">
                                    <p class="place-price-txt">$36/night</p>
                                </div>
                            </div>
                            <h3 class="place-title">The Tree House</h3>
                            <p class="place-caption">Book unique camping experiences on over 300,000 campsites.</p>
                            <a href="#" class="btn place-link">Read More</a>
                        </div>
                        <div class="palce">
                            <div class="place-banner">
                                <img src="../images/image11.jpg" alt="" class="place-img">
                                <div class="place-like">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="place-like-icon active-3" width="24.037" height="24.037" viewBox="0 0 24.037 24.037" fill="#fff" stroke="#e76f51" stroke-width="1.5">
                                        <path id="Path_955" data-name="Path 955" d="M15.822,8.979v.029H4V-2.1A5.915,5.915,0,0,1,9.912-7.841a5.913,5.913,0,0,1,5.849,5.049,5.912,5.912,0,0,1,.061,11.772Z" transform="translate(2.716 20.496) rotate(-45)"/>
                                    </svg> 
                                </div>
                                <div class="place-price">
                                    <p class="place-price-txt">$36/night</p>
                                </div>
                            </div>
                            <h3 class="place-title">Barrier island elevated tent</h3>
                            <p class="place-caption">Book unique camping experiences on over 300,000 campsites.</p>
                            <a href="#" class="btn place-link">Read More</a>
                        </div>
                        <div class="palce">
                            <div class="place-banner">
                                <img src="../images/image12.jpg" alt="" class="place-img">
                                <div class="place-like">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="place-like-icon" width="24.037" height="24.037" viewBox="0 0 24.037 24.037" fill="#fff" stroke="#e76f51" stroke-width="1.5">
                                        <path id="Path_955" data-name="Path 955" d="M15.822,8.979v.029H4V-2.1A5.915,5.915,0,0,1,9.912-7.841a5.913,5.913,0,0,1,5.849,5.049,5.912,5.912,0,0,1,.061,11.772Z" transform="translate(2.716 20.496) rotate(-45)"/>
                                    </svg> 
                                </div>
                                <div class="place-price">
                                    <p class="place-price-txt">$36/night</p>
                                </div>
                            </div>
                            <h3 class="place-title">Ninovan on the Shore</h3>
                            <p class="place-caption">Book unique camping experiences on over 300,000 campsites.</p>
                            <a href="#" class="btn place-link">Read More</a>
                        </div>
                    </div>
                    <a href="#" class="btn destination-link">View all</a>
                </section>
                <section class="newsletter">
                    <div class="newsletter-content">
                        <h2 class="newsletter-title">Let's Stay in Touch</h2>
                        <p class="newsletter-caption">Get travel planning ideas, helpful tips, and stories from our visitors delivered right to your inbox.</p>
                        <div class="newsletter-email-box">
                            <form action="" class="newsletter-form">
                                <svg xmlns="http://www.w3.org/2000/svg" class="newsletter-email-icon" width="24.242" height="17.746" viewBox="0 0 24.242 17.746">
                                    <path id="Path_908" data-name="Path 908" d="M26.215,17.058H8.027A3.03,3.03,0,0,0,5,20.085V31.777A3.031,3.031,0,0,0,8.027,34.8H26.215a3.031,3.031,0,0,0,3.027-3.027V20.085A3.03,3.03,0,0,0,26.215,17.058Zm-18.188.857H26.215a2.168,2.168,0,0,1,1.829,1.007l-9.328,8.81a2.354,2.354,0,0,1-3.189,0L6.2,18.923A2.169,2.169,0,0,1,8.027,17.915ZM5.878,32.062a2.207,2.207,0,0,1-.021-.285V20.085a2.163,2.163,0,0,1,.021-.285l6.491,6.131Zm20.337,1.885H8.027A2.168,2.168,0,0,1,6.2,32.94l6.8-6.419,1.944,1.835a3.22,3.22,0,0,0,4.366,0l1.943-1.835,6.8,6.418A2.167,2.167,0,0,1,26.215,33.947Zm2.169-13.862V31.777a2.2,2.2,0,0,1-.021.285l-6.491-6.131L28.364,19.8A2.251,2.251,0,0,1,28.384,20.085Z" transform="translate(-5 -17.058)" fill="#8d8d8d"/>
                                </svg>
                                <input type="text" class="newsletter-input" placeholder="Email Address">
                                <button class="newsletter-submit">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24.162" height="18.23" viewBox="0 0 24.162 18.23">
                                        <path id="Path_909" data-name="Path 909" d="M9.778,15.82,6.954,17.7a.55.55,0,0,1-.816-.439V13.121l11.546-8.66L3.88,11.8.3,9.356A.748.748,0,0,1,.491,8.039L23.709-.37c.314-.126.565.251.377.565L13.606,17.514a.773.773,0,0,1-1.067.188Z" transform="translate(0.012 0.395)" fill="#fff" fill-rule="evenodd"/>
                                    </svg>
                                </button>
                            </form>
                        </div>
                    </div>
                    <div class="newsletter-banner">
                        <img src="../images/tent.png" alt="newsletter" class="newsletter-img">
                    </div>
                </section>
            </div>
        </main>
        <footer class="footer">
            <div class="container">
                <div class="all-wrapper">
                    <div class="footer-wraper-left">
                        <div class="footer-content">
                            <h2 class="footer-title">Hipcamp is everywhere you want to camp.</h2>
                            <p class="footer-caption">Discover unique experiences on ranches, nature preserves, farms, vineyards, and public campgrounds across the U.S. Book tent camping, treehouses, cabins, yurts, primitive backcountry sites, car camping, airstreams, tiny houses, RV camping, glamping tents and more.</p>
                        </div>
                        <div class="footer-app">
                            <h2 class="footer-title">Download Our App</h2>
                            <a href="#" class="footer-app-link">
                                <img src="../images/app-store-apple.jpg" class="footer-app-img" alt="app-store">
                            </a>
                            <a href="#" class="footer-app-link">
                                <img src="../images/google-play.jpg" class="footer-app-img" alt="google-play">
                            </a>
                        </div>
                    </div>
                    <div class="footer-wrapper-right">
                        <div class="footer-list">
                            <h2 class="footer-title">Get to Know Us</h2>
                            <ul class="footer-pages">
                                <li class="footer-pages-item">
                                    <a href="#" class="footer-pages-link">About Us</a>
                                </li>
                                <li class="footer-pages-item">
                                    <a href="#" class="footer-pages-link">About Us</a>
                                </li>
                                <li class="footer-pages-item">
                                    <a href="#" class="footer-pages-link">About Us</a>
                                </li>
                                <li class="footer-pages-item">
                                    <a href="#" class="footer-pages-link">About Us</a>
                                </li>
                                <li class="footer-pages-item">
                                    <a href="#" class="footer-pages-link">About Us</a>
                                </li>
                            </ul>
                        </div>
                        <div class="footer-list">
                            <h2 class="footer-title">Plan with Us</h2>
                            <ul class="footer-pages">
                                <li class="footer-pages-item">
                                    <a href="#" class="footer-pages-link">Find Trip Inspiration</a>
                                </li>
                                <li class="footer-pages-item">
                                    <a href="#" class="footer-pages-link">Find Trip Inspiration</a>
                                </li>
                                <li class="footer-pages-item">
                                    <a href="#" class="footer-pages-link">Find Trip Inspiration</a>
                                </li>
                                <li class="footer-pages-item">
                                    <a href="#" class="footer-pages-link">Find Trip Inspiration</a>
                                </li>
                            </ul>
                        </div>
                        <div class="footer-list">
                            <h2 class="footer-title">Let Us Help You</h2>
                            <ul class="footer-pages">
                                <li class="footer-pages-item">
                                    <a href="#" class="footer-pages-link">Your Account</a>
                                </li>
                                <li class="footer-pages-item">
                                    <a href="#" class="footer-pages-link">Your Account</a>
                                </li>
                                <li class="footer-pages-item">
                                    <a href="#" class="footer-pages-link">Your Account</a>
                                </li>
                                <li class="footer-pages-item">
                                    <a href="#" class="footer-pages-link">Your Account</a>
                                </li>
                                <li class="footer-pages-item">
                                    <a href="#" class="footer-pages-link">Your Account</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
    </body>
<script src="script.js"></script>
</html>